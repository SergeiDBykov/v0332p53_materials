Those are results from a paper. 

The figures are per-observation 3-12 keV count-rate pulse profiles normalised to the mean value.  


Top panel: 
the count-rate in 3-12 keV range pulse profile. They are shift along the x-axis to have the main minimum at phase 0.

Bottom panel: 
the 3-12 keV light curve of the source in 2004 outburst (as in fig. 2, panel A of the paper), with the vertical red line being the time an observation was made.



The file names are MJD_{xxx}_{yyy}
where {xxx} is the MJD of observation start and {yyy} is the observation ID. 
